package ruhack.rickdlc.system.modulesystem.impl.movement;

import com.adl.nativeprotect.Native;
import net.minecraft.block.Blocks;
import ruhack.rickdlc.system.eventsystem.api.EventHandler;
import ruhack.rickdlc.system.eventsystem.impl.TickEvent;
import ruhack.rickdlc.system.modulesystem.ModuleStructure;
import ruhack.rickdlc.system.modulesystem.category.ModuleCategory;
import ruhack.rickdlc.system.modulesystem.setting.implement.SelectSetting;
import ruhack.rickdlc.util.istance.Instance;
import ruhack.rickdlc.util.player.MovingUtil;
import ruhack.rickdlc.util.string.PlayerInteractionHelper;

public class AntiWeb extends ModuleStructure {
   public final SelectSetting webMode = new SelectSetting("Режим", "Выберите режим обхода", "Grim", "Grim");

   public static AntiWeb getInstance() {
      return Instance.get(AntiWeb.class);
   }

   public AntiWeb() {
      super("AntiWeb", "Ускоряет игрока в паутине", ModuleCategory.MOVEMENT);
      this.settings(this.webMode);
   }

   @EventHandler
   @Native
   public void onTick(TickEvent e) {
      if (PlayerInteractionHelper.isPlayerInBlock(Blocks.COBWEB)) {
         double[] speed = MovingUtil.calculateDirection(0.35);
         mc.player.addVelocity(speed[0], 0.0, speed[1]);
         mc.player.setVelocity(speed[0], mc.options.jumpKey.isPressed() ? 0.65F : (mc.options.sneakKey.isPressed() ? -0.65F : 0.0), speed[1]);
      }
   }
}
