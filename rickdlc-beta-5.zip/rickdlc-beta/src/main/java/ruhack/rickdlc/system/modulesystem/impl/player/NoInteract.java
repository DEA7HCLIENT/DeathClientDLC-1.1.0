package ruhack.rickdlc.system.modulesystem.impl.player;

import ruhack.rickdlc.system.modulesystem.ModuleStructure;
import ruhack.rickdlc.system.modulesystem.category.ModuleCategory;
import ruhack.rickdlc.util.istance.Instance;

public class NoInteract extends ModuleStructure {
   public static NoInteract getInstance() {
      return Instance.get(NoInteract.class);
   }

   public NoInteract() {
      super("NoInteract", "Не дает взаимодействовать с блоками", ModuleCategory.PLAYER);
   }
}
