package ruhack.rickdlc.system.screensystem.clickgui;

import ruhack.rickdlc.system.modulesystem.ModuleStructure;

public record ModuleCardBounds(ModuleStructure module, float x, float y, float width, float height) {
}
