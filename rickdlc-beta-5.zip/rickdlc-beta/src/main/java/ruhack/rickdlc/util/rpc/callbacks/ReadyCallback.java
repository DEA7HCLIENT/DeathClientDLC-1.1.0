package ruhack.rickdlc.util.rpc.callbacks;

import com.sun.jna.Callback;
import ruhack.rickdlc.util.rpc.utils.DiscordUser;

public interface ReadyCallback extends Callback {
   void apply(DiscordUser var1);
}
