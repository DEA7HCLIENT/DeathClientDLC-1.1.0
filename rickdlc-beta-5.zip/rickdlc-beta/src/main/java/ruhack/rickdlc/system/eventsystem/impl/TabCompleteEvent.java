package ruhack.rickdlc.system.eventsystem.impl;

import ruhack.rickdlc.system.eventsystem.api.events.callables.EventCancellable;

public class TabCompleteEvent extends EventCancellable {
   public final String prefix;
   public String[] completions;

   public TabCompleteEvent(String prefix) {
      this.prefix = prefix;
      this.completions = null;
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void setCompletions(String[] completions) {
      this.completions = completions;
   }
}
