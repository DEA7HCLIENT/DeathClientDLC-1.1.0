package ruhack.rickdlc.system.eventsystem.impl;

import ruhack.rickdlc.system.eventsystem.api.events.Event;

public class GameLeftEvent implements Event {
   private static final GameLeftEvent INSTANCE = new GameLeftEvent();

   public static GameLeftEvent get() {
      return INSTANCE;
   }
}
