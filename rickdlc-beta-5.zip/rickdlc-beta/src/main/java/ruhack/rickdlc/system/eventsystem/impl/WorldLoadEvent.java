package ruhack.rickdlc.system.eventsystem.impl;

import ruhack.rickdlc.system.eventsystem.api.events.Event;

public class WorldLoadEvent implements Event {
}
