package ruhack.rickdlc.mixin;

import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.world.ClientWorld.Properties;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ClientWorld.class)
public interface ClientWorldAccessor {
   @Accessor("pendingUpdateManager")
   PendingUpdateManager rickdlc$getPendingUpdateManager();

   @Accessor("clientWorldProperties")
   Properties rickdlc$getClientWorldProperties();
}
