package ruhack.rickdlc.system.macrosystem;

public record Macro(String name, String message, int key) {
}
