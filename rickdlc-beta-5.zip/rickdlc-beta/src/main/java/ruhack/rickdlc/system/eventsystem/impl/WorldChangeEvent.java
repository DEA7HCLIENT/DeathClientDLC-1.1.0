package ruhack.rickdlc.system.eventsystem.impl;

import ruhack.rickdlc.system.eventsystem.api.events.Event;

public class WorldChangeEvent implements Event {
   private static final WorldChangeEvent INSTANCE = new WorldChangeEvent();

   public static WorldChangeEvent get() {
      return INSTANCE;
   }
}
