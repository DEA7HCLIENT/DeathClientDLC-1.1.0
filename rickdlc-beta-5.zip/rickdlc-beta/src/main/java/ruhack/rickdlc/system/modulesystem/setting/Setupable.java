package ruhack.rickdlc.system.modulesystem.setting;

public interface Setupable {
   void settings(Setting... var1);
}
